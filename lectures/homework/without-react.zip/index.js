//변수
const firstName = "상훈";
const lastName = "한";
const fullName = lastName + firstName;

//element생성


//div에 추가

